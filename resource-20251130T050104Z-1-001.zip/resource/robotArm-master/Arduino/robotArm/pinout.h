#ifndef PINOUT_H_
#define PINOUT_H_

//up and down direction
#define Z_STEP_PIN         54
#define Z_DIR_PIN          55
#define Z_ENABLE_PIN       38

//rotate
#define X_STEP_PIN         60
#define X_DIR_PIN          61
#define X_ENABLE_PIN       56

//forword and backword
#define Y_STEP_PIN         46
#define Y_DIR_PIN          48
#define Y_ENABLE_PIN       62



#define FAN_PIN             9

//gripper arm
#define STEPPER_GRIPPER_PIN_0 32
#define STEPPER_GRIPPER_PIN_1 36
#define STEPPER_GRIPPER_PIN_2 34
#define STEPPER_GRIPPER_PIN_3 40


#endif
