# Robot-Flooring-Tobler
This is my first robot arm project.
# G code list

  moveHome -
        G90\r                      // Set to ABSOLUTE coordinate mode 
        G28\r                       // Go to home position (end-stop)
        G1 X0 Y120 Z100 F30\r       // Move to a good "Ready" position
        G91\r                        // Set to RELATIVE coordinate mode
        
 // Relative move single axis
       G91\r // Set to RELATIVE coordinate mode
       G1 Xvalue Fspeed\r
       G1 Yvalue Fspeed\r
       G1 Zvalue Fspeed\r

// Absolute move multiple axis
       G90\r // Set to ABSOLUTE coordinate mode       

// Gripper functions
    openGripper - M3\r
    closeGripper - M5\r
    powerUpSteppers - M17\r
    powerDownSteppers - M18\r     
